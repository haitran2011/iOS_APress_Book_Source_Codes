//
//  HeroEditController.h
//  SuperDB
//
//  Created by Kevin Kim on 7/18/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeroEditController : UITableViewController

@property (strong, nonatomic) id hero;

@end
