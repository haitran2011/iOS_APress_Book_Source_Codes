//
//  main.m
//  SuperDB
//
//  Created by Kevin Kim on 7/14/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SuperDBAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SuperDBAppDelegate class]));
    }
}
