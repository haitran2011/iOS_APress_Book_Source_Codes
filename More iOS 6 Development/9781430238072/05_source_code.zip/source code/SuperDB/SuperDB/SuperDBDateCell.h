//
//  SuperDBDateCell.h
//  SuperDB
//
//  Created by Kevin Kim on 8/9/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBEditableCell.h"

@interface SuperDBDateCell : SuperDBEditableCell
{
    UIDatePicker *_datePicker;
    NSDate *_date;
}

- (NSDateFormatter *)dateFormatter;
- (IBAction)dateChanged:(id)sender;

@end
