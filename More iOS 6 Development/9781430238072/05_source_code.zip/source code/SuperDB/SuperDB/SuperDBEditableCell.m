//
//  SuperDBEditableCell.m
//  SuperDB
//
//  Created by Kevin Kim on 8/8/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBEditableCell.h"

#define kLabelColor [UIColor colorWithRed:0.32 green:0.40 blue:0.57 alpha:1.0]

@implementation SuperDBEditableCell

@synthesize textLabel;
@synthesize textField;
@synthesize keyPath;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
            
        self.textLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 10.0, 60, 24)];
        self.textLabel.backgroundColor = [UIColor clearColor];
        self.textLabel.font = [UIFont boldSystemFontOfSize:[UIFont smallSystemFontSize]];
        self.textLabel.textAlignment = UITextAlignmentRight;
        self.textLabel.textColor = kLabelColor;
            
        self.textField = [[UITextField alloc] initWithFrame:CGRectMake(80.0, 12.0, 180, 24)];
        self.textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.textField.enabled = NO;
        self.textField.font = [UIFont boldSystemFontOfSize:15.0];
            
        [self.contentView addSubview:textLabel];
        [self.contentView addSubview:textField];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setEditing:(BOOL)editing
{
    [super setEditing:editing];
    self.textField.enabled = editing;
}

- (id)value
{
    return self.textField.text;
}

- (void)setValue:(id)value
{
    self.textField.text = value;
}

@end
