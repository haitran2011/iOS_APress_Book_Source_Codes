//
//  HeroDetailController.h
//  SuperDB
//
//  Created by Kevin Kim on 8/1/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeroDetailController : UITableViewController {
    UIBarButtonItem *saveButton;
    UIBarButtonItem *backButton;
    UIBarButtonItem *cancelButton;
}

@property (strong, nonatomic) NSArray *sections;
@property (strong, nonatomic) NSManagedObject *hero;

- (void)saveEditing;
- (void)cancelEditing;

@end
