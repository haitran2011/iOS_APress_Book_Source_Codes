//
//  UIColorPicker.h
//  SuperDB
//
//  Created by Kevin Kim on 9/13/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColorPicker : UIControl
{
    UISlider *_redSlider;
    UISlider *_greenSlider;
    UISlider *_blueSlider;
    UISlider *_alphaSlider;    
}

@property (nonatomic, retain) UIColor *color;

- (UILabel *)labelWithFrame:(CGRect)frame text:(NSString *)text;
- (IBAction)sliderChanged:(id)sender;

@end
