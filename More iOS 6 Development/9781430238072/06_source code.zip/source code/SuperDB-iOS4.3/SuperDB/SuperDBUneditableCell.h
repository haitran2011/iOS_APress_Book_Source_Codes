//
//  SuperDBUneditableCell.h
//  SuperDB
//
//  Created by Kevin Kim on 9/15/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBEditableCell.h"

@interface SuperDBUneditableCell : SuperDBEditableCell

@end
