//
//  SuperDBUneditableCell.m
//  SuperDB
//
//  Created by Kevin Kim on 9/15/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBUneditableCell.h"

@implementation SuperDBUneditableCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code here.
        [super setEditing:NO];
        self.textField.enabled = NO;
    }
    
    return self;
}

- (void)setEditing:(BOOL)editing
{
}


@end
