//
//  Hero.h
//  SuperDB
//
//  Created by Kevin Kim on 9/13/11.
//  Copyright (c) 2011 App Orchard LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

#define kHeroValidationDomain  @"com.AppOrchard.SuperDB.HeroValidationDomain"
#define kHeroValidationBirthdateCode  1000

@interface Hero : NSManagedObject

@property (nonatomic, retain) NSDate * birthdate;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * secretIdentity;
@property (nonatomic, retain) NSString * sex;
@property (nonatomic, readonly) NSNumber * age;
@property (nonatomic, retain) UIColor *favoriteColor;

@end
