//
//  SuperDBPickerCell.m
//  SuperDB
//
//  Created by Kevin Kim on 8/9/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBPickerCell.h"

@implementation SuperDBPickerCell

@synthesize values;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.textField.clearButtonMode = UITextFieldViewModeNever;
        
        _pickerView = [[UIPickerView alloc] initWithFrame:CGRectZero];
        _pickerView.delegate = self;
        _pickerView.dataSource = self;
        _pickerView.showsSelectionIndicator = YES;
        self.textField.inputView = _pickerView;
    }
    
    return self;
}

#pragma mark override value accessor and setter

- (void)setValue:(id)value
{
    if (NSNotFound != [self.values indexOfObject:value]) {
        _currentValue = value;
        [super setValue:value];
    }
}

#pragma mark PickerView delegate

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [self.values objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    _currentValue = [self.values objectAtIndex:row];
    self.textField.text = _currentValue;
}

#pragma mark PickerView data source

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [self.values count];
}

#pragma accessors for editing property

- (void)setEditing:(BOOL)editing
{
    if (editing) {
        NSUInteger row = [self.values indexOfObject:_currentValue];
        if (NSNotFound != row)
            [_pickerView selectRow:row inComponent:0 animated:NO];
    }
    [super setEditing:editing];
}

@end
