//
//  HeroDetailController.h
//  SuperDB
//
//  Created by Kevin Kim on 9/13/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeroDetailController : UITableViewController
{
    UIBarButtonItem *saveButton;
    UIBarButtonItem *backButton;
    UIBarButtonItem *cancelButton;
}

@property (nonatomic, retain) NSArray *sections;
@property (nonatomic, retain) NSManagedObject *hero;

- (void)saveEditing;
- (void)cancelEditing;

@end
