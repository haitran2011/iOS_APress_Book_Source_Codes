//
//  SuperDBColorCell.m
//  SuperDB
//
//  Created by Kevin Kim on 9/13/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBColorCell.h"
#import "UIColorPicker.h"

@implementation SuperDBColorCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.textField.clearButtonMode = UITextFieldViewModeNever;
        self.textField.text = [NSString stringWithFormat:@"%C%C%C%C%C%C%C%C%C%C", 0x2588, 0x2588, 0x2588, 0x2588, 0x2588, 0x2588, 0x2588, 0x2588, 0x2588, 0x2588];
        _colorPicker = [[UIColorPicker alloc] initWithFrame:CGRectZero];
        [_colorPicker addTarget:self action:@selector(colorChanged:) forControlEvents:UIControlEventValueChanged];
        self.textField.inputView = _colorPicker;
    }
    
    return self;
}

#pragma mark override value accessor and setter

- (id)value
{
    return _color;
}

- (void)setValue:(id)value
{
    _color = value;
    if (_color) {
        [_colorPicker setColor:_color];
        self.textField.textColor = _color;
    }
}
    
- (IBAction)colorChanged:(id)sender
{
    [self setValue:[_colorPicker color]];
}
    
@end
