//
//  SuperDBDateCell.m
//  SuperDB
//
//  Created by Kevin Kim on 8/9/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBDateCell.h"

@implementation SuperDBDateCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code here.
        self.textField.clearButtonMode = UITextFieldViewModeNever;
        
        _datePicker = [[UIDatePicker alloc] initWithFrame:CGRectZero];
        _datePicker.datePickerMode = UIDatePickerModeDate;
        [_datePicker addTarget:self action:@selector(dateChanged:) forControlEvents:UIControlEventValueChanged];
        self.textField.inputView = _datePicker;
    }
    
    return self;
}

- (id)value
{
    return _date;
}

- (void)setValue:(id)value
{
    _date = value;
    if (_date) {
        [_datePicker setDate:_date];
        self.textField.text = [[self dateFormatter] stringFromDate:_date];
    }
}

- (NSDateFormatter *)dateFormatter
{
    static NSDateFormatter *staticDateFormatter;
    if (nil == staticDateFormatter)
    {
        staticDateFormatter = [[NSDateFormatter alloc] init];
        [staticDateFormatter setDateStyle:NSDateFormatterMediumStyle];
    }
    return staticDateFormatter;    
}

- (IBAction)dateChanged:(id)sender
{
    _date = [_datePicker date];
    self.textField.text = [[self dateFormatter] stringFromDate:_date];
}

@end
