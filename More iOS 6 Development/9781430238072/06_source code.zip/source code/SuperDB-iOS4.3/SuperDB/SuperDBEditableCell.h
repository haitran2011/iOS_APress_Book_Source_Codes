//
//  SuperDBEditableCell.h
//  SuperDB
//
//  Created by Kevin Kim on 9/13/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuperDBEditableCell : UITableViewCell <UITextFieldDelegate, UIAlertViewDelegate>

@property (nonatomic, retain) IBOutlet UILabel *textLabel;
@property (nonatomic, retain) IBOutlet UITextField *textField;
@property (nonatomic, retain) id value;
@property (nonatomic, retain) NSString *keyPath;
@property (nonatomic, retain) NSManagedObject *managedObject;
@property (nonatomic, retain) NSString *formatterClassname;

- (IBAction)validate;
- (BOOL)isTransient;

@end
