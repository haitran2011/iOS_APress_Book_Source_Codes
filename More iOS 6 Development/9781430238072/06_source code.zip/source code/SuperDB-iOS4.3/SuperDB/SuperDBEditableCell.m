//
//  SuperDBEditableCell.m
//  SuperDB
//
//  Created by Kevin Kim on 9/13/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBEditableCell.h"

#define kLabelColor [UIColor colorWithRed:0.32 green:0.40 blue:0.57 alpha:1.0]

@implementation SuperDBEditableCell

@synthesize textLabel;
@synthesize textField;
@synthesize keyPath;
@synthesize managedObject;
@synthesize formatterClassname;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.textLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 10.0, 60, 24)];
        self.textLabel.backgroundColor = [UIColor clearColor];
        self.textLabel.font = [UIFont boldSystemFontOfSize:[UIFont smallSystemFontSize]];
        self.textLabel.textAlignment = UITextAlignmentRight;
        self.textLabel.textColor = kLabelColor;
        
        self.textField = [[UITextField alloc] initWithFrame:CGRectMake(80.0, 12.0, 180, 24)];
        self.textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.textField.enabled = NO;
        self.textField.font = [UIFont boldSystemFontOfSize:15.0];
        self.textField.delegate = self;
        
        [self.contentView addSubview:textLabel];
        [self.contentView addSubview:textField];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setEditing:(BOOL)editing
{
    [super setEditing:editing];
    self.textField.enabled = editing;
}

- (id)value
{
    return self.textField.text;
}

- (void)setValue:(id)value
{
    if (nil != self.formatterClassname) { 
        if (nil != value) {
            NSFormatter *formatter = [[NSClassFromString(formatterClassname) alloc] init];
            self.textField.text = [formatter stringForObjectValue:value];
        }
    }
    else
        self.textField.text = value;
}

- (IBAction)validate
{
    id val = self.value;
    NSError *error;
    if (![self.managedObject validateValue:&val forKey:self.keyPath error:&error]) {
        NSString *message = nil;
        if ([[error domain] isEqualToString:@"NSCocoaErrorDomain"]) {
            NSDictionary *userInfo = [error userInfo];
            message = [NSString stringWithFormat:NSLocalizedString(@"Validation error on %@\rFailed condition: %@", @"Validation error on %@, (failed condition: %@)"), [userInfo valueForKey:@"NSValidationErrorKey"], [error localizedFailureReason]];
        }
        else
            message = [error localizedDescription];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Validation Error", @"Validation Error") message:message delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"Cancel") otherButtonTitles:NSLocalizedString(@"Fix", @"Fix"), nil];
        [alert show];
    }
}

- (BOOL)isTransient
{
    NSAttributeDescription *attrDesc = [[[self.managedObject entity] attributesByName] valueForKey:self.keyPath];
    return [attrDesc isTransient];
}

#pragma mark UITextFieldDelegate methods

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self validate];
}

#pragma mark Alert View Delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == [alertView cancelButtonIndex])
        [self setValue:[self.managedObject valueForKeyPath:self.keyPath]];
    else
        [self.textField becomeFirstResponder];
}

@end
