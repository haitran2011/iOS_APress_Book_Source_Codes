//
//  SuperDBColorCell.h
//  SuperDB
//
//  Created by Kevin Kim on 9/13/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBEditableCell.h"

@class UIColorPicker;

@interface SuperDBColorCell : SuperDBEditableCell
{
    UIColorPicker *_colorPicker;
    UIColor *_color;
}

- (IBAction)colorChanged:(id)sender;

@end
