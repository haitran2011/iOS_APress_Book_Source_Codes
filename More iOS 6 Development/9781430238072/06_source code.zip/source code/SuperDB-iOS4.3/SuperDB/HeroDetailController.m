//
//  HeroDetailController.m
//  SuperDB
//
//  Created by Kevin Kim on 9/13/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "HeroDetailController.h"
#import "SuperDBEditableCell.h"

@implementation HeroDetailController

@synthesize sections = _sections;
@synthesize hero = _hero;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSDictionary *settings =  [NSDictionary dictionaryWithContentsOfURL:[[NSBundle mainBundle] URLForResource:@"HeroDetailController" withExtension:@"plist"]];
    self.sections = [settings valueForKey:@"sections"];
    
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
    saveButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveEditing)];
    backButton = self.navigationItem.leftBarButtonItem;
    cancelButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelEditing)];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.sections count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *rows = [[self.sections objectAtIndex:section] valueForKey:@"rows"];
    return [rows count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *rows = [[self.sections objectAtIndex:[indexPath section]] valueForKey:@"rows"];
    NSDictionary *row = [rows objectAtIndex:[indexPath row]];
    NSString *cellClassname = [row valueForKey:@"class"];
    
    SuperDBEditableCell *cell = (SuperDBEditableCell *)[tableView dequeueReusableCellWithIdentifier:cellClassname];
    if (cell == nil) {
        Class cellClass = NSClassFromString(cellClassname);
        cell = [cellClass alloc];
        cell = [cell initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:cellClassname];
    }
    
    NSString *attribute = [row valueForKey:@"attribute"];    
    cell.formatterClassname = [row valueForKey:@"formatter"];
    cell.textLabel.text = [row valueForKey:@"label"];
    cell.value = [self.hero valueForKey:attribute];
    cell.keyPath = attribute;
    cell.managedObject = self.hero;
    
    NSDictionary *arguments = [row valueForKey:@"arguments"];
    for (NSString *key in arguments)
        [cell setValue:[arguments valueForKey:key] forKey:key];

    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return  NSLocalizedString([[self.sections objectAtIndex:section] valueForKey:@"header"], @"Section Header");
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return UITableViewCellEditingStyleNone;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     [detailViewController release];
     */
}

- (void) toggleButtons
{
    if (self.editing) {
        self.navigationItem.leftBarButtonItem = cancelButton;
        self.navigationItem.rightBarButtonItem = saveButton;
    }
    else {
        self.navigationItem.leftBarButtonItem = backButton;
        self.navigationItem.rightBarButtonItem = self.editButtonItem;
    }
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];

    for (SuperDBEditableCell *cell in [self.tableView visibleCells])
        [cell setEditing:editing];

    [self toggleButtons];
}

- (void)saveEditing
{
    [self setEditing:NO animated:YES];
    for (SuperDBEditableCell *cell in [self.tableView visibleCells])
        if (![cell isTransient])
            [self.hero setValue:[cell value] forKeyPath:[cell keyPath]];
    
    NSError *error;
    if (![self.hero.managedObjectContext save:&error])
        NSLog(@"Error saving: %@", [error localizedDescription]);
}

- (void)cancelEditing
{
    [self setEditing:NO animated:YES];
}

@end
