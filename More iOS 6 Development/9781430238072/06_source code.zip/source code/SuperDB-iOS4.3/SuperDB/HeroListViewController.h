//
//  HeroListViewController.h
//  SuperDB
//
//  Created by Kevin Kim on 9/13/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kSelectedTabDefaultsKey @"Selected Tab"

enum {
    kByName,
    kBySecretIdentity,
};

@class HeroDetailController;

@interface HeroListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITabBarDelegate, UIAlertViewDelegate, NSFetchedResultsControllerDelegate> 

@property (nonatomic, retain) IBOutlet UITableView *tableView;
@property (nonatomic, retain) IBOutlet UITabBar *tabBar;
@property (nonatomic, readonly) NSFetchedResultsController *fetchedResultsController;
@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain) IBOutlet HeroDetailController *heroDetailController;

- (void)addHero;
- (IBAction)toggleEdit;

@end
