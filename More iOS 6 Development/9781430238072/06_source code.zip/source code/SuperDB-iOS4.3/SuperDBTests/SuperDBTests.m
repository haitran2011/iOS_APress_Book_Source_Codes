//
//  SuperDBTests.m
//  SuperDBTests
//
//  Created by Kevin Kim on 9/13/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBTests.h"

@implementation SuperDBTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SuperDBTests");
}

@end
