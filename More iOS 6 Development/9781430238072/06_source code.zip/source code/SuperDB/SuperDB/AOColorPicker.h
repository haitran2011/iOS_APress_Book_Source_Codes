//
//  AOColorPicker.h
//  SuperDB
//
//  Created by Kevin Kim on 8/16/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AOColorPicker : UIControl
{
    UISlider *_redSlider;
    UISlider *_greenSlider;
    UISlider *_blueSlider;
    UISlider *_alphaSlider;    
}

@property (strong, nonatomic) UIColor *color;

- (UILabel *)labelWithFrame:(CGRect)frame text:(NSString *)text;
- (IBAction)sliderChanged:(id)sender;

@end
