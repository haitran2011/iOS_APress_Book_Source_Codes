//
//  UIColorRGBValueTransformer.h
//  SuperDB
//
//  Created by Kevin Kim on 8/16/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColorRGBValueTransformer : NSObject

@end
