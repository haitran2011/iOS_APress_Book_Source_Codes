//
//  SuperDBColorCell.h
//  SuperDB
//
//  Created by Kevin Kim on 8/16/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBEditableCell.h"

@class AOColorPicker;

@interface SuperDBColorCell : SuperDBEditableCell
{
    AOColorPicker *_colorPicker;
    UIColor *_color;
}

- (IBAction)colorChanged:(id)sender;

@end
