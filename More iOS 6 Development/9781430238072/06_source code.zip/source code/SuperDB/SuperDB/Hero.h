//
//  Hero.h
//  SuperDB
//
//  Created by Kevin Kim on 8/16/11.
//  Copyright (c) 2011 App Orchard LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

#define kHeroValidationDomain        @"com.AppOrchard.SuperDB.HeroValidationDomain"
#define kHeroValidationBirthdateCode 1000
#define kHeroValidationName          1001

@interface Hero : NSManagedObject

@property (strong, nonatomic) NSDate   * birthdate;
@property (strong, nonatomic) NSString * name;
@property (strong, nonatomic) NSString * secretIdentity;
@property (strong, nonatomic) NSString * sex;
@property (strong, readonly)  NSString * age;
@property (strong, nonatomic) UIColor  * favoriteColor;

@end
