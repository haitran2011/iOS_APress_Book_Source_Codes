//
//  Hero.m
//  SuperDB
//
//  Created by Kevin Kim on 8/16/11.
//  Copyright (c) 2011 App Orchard LLC. All rights reserved.
//

#import "Hero.h"


@implementation Hero

@dynamic birthdate;
@dynamic name;
@dynamic secretIdentity;
@dynamic sex;
@dynamic age;
@dynamic favoriteColor;

- (void) awakeFromInsert {
    self.favoriteColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:1.0];
    [super awakeFromInsert];
}

-(BOOL)validateBirthdate:(id *)ioValue error:(NSError **)outError
{  
    NSDate *date = *ioValue;
    if ([date compare:[NSDate date]] ==  NSOrderedDescending) {
        if (outError != NULL) {
            NSString *errorStr = NSLocalizedString(@"Birthdate cannot be in the future", @"Birthdate cannot be in the future");
            NSDictionary *userInfoDict = [NSDictionary dictionaryWithObject:errorStr forKey:NSLocalizedDescriptionKey];
            NSError *error = [[NSError alloc] initWithDomain:kHeroValidationDomain code:kHeroValidationBirthdateCode userInfo:userInfoDict];
            *outError = error;
        }
        return NO;
    }
    return YES;
}

- (NSString *)age
{
    if (nil == self.birthdate)
        return nil;
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [gregorian components:NSYearCalendarUnit fromDate:self.birthdate toDate:[NSDate date] options:0];
    NSInteger years = [components year];
    return [[NSNumber numberWithInteger:years] stringValue];
}

@end
