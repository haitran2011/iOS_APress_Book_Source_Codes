//
//  SuperDBEditableCell.h
//  SuperDB
//
//  Created by Kevin Kim on 8/8/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuperDBEditableCell : UITableViewCell <UITextFieldDelegate, UIAlertViewDelegate>

@property (strong, nonatomic) IBOutlet UILabel *textLabel;
@property (strong, nonatomic) IBOutlet UITextField *textField;
@property (strong, nonatomic) id value;
@property (strong, nonatomic) NSString *keyPath;
@property (strong, nonatomic) NSManagedObject *managedObject;

- (IBAction)validate;
- (BOOL)isTransient;

@end
