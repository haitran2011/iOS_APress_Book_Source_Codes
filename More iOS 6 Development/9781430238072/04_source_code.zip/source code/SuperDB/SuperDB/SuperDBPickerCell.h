//
//  SuperDBPickerCell.h
//  SuperDB
//
//  Created by Kevin Kim on 8/9/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import "SuperDBEditableCell.h"

@interface SuperDBPickerCell : SuperDBEditableCell <UIPickerViewDelegate, UIPickerViewDataSource> {
    UIPickerView *_pickerView;
    NSString *_currentValue;
}

@property (strong, nonatomic) NSArray *values;

@end
