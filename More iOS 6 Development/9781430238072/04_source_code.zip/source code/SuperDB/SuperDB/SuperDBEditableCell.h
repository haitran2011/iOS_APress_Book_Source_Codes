//
//  SuperDBEditableCell.h
//  SuperDB
//
//  Created by Kevin Kim on 8/8/11.
//  Copyright 2011 App Orchard LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuperDBEditableCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *textLabel;
@property (strong, nonatomic) IBOutlet UITextField *textField;
@property (strong, nonatomic) id value;
@property (strong, nonatomic) NSString *keyPath;

@end
