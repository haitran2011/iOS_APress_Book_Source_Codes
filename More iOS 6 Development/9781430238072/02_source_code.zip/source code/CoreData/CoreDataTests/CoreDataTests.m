//
//  CoreDataTests.m
//  CoreDataTests
//
//  Created by Alex Horovitz on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CoreDataTests.h"

@implementation CoreDataTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in CoreDataTests");
}

@end
