//
//  CoreDataTests.h
//  CoreDataTests
//
//  Created by Alex Horovitz on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CoreDataTests : SenTestCase

@end
