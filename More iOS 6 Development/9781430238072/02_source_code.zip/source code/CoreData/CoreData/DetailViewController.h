//
//  DetailViewController.h
//  CoreData
//
//  Created by Alex Horovitz on 7/11/11.
//  Copyright 2011 AppOrchard a Tipping Point Partners company. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NSManagedObject+Insert.h"

@interface DetailViewController : UIViewController

@property (strong, nonatomic) id detailItem;

@property (strong, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

@end
