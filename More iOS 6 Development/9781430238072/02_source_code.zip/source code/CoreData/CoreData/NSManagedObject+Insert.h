//
//  NSManagedObject-Insert.h
//  CoreData
//
//  Created by Alex Horovitz on 7/19/11.
//  Copyright 2011 AppOrchard a Tipping Point Partners company. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface NSManagedObjectContext (NSManagedObject_Insert)

-(NSManagedObject *) insertNewEntityWithName:(NSString *)name;

@end
