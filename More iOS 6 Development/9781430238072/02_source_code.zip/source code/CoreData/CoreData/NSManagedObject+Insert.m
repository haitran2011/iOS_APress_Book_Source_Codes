//
//  NSManagedObject-Insert.m
//  CoreData
//
//  Created by Alex Horovitz on 7/19/11.
//  Copyright 2011 AppOrchard a Tipping Point Partners company. All rights reserved.
//

#import "NSManagedObject+Insert.h"

@implementation NSManagedObjectContext (NSManagedObject_Insert)

-(NSManagedObject *) insertNewEntityWithName:(NSString *)name
{
    return [NSEntityDescription insertNewObjectForEntityForName:name inManagedObjectContext:self];
}

@end
